<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;


class MyQueryController extends Controller
{
    
        public function quertIndex(){ 
            return view('queryform');
        }

        public function dataStore(Request $request){ 

            // dd($request->all());
            // print_r($request);
                  
             $request->validate([
                'name' => 'required',
                'email' => 'required|email',
                'subject' => 'required',
                'userfile' => 'required|mimes:jpg,jpeg,png,gif,pdf|max:2048',
                'desc' => 'required|min:4'
 
            ]);


            if($request->file('userfile')) {

                $fileName = time().'_'.$request->file('userfile')->getClientOriginalName();
                $filePath = $request->file('userfile')->move(public_path('uploads'), $fileName); 
                $request->file('userfile')->getClientOriginalName();
                // $extension = pathinfo($filePath, PATHINFO_EXTENSION);
               
                // return back()
                // ->with('success','File has been uploaded.')
                // ->with('file', $fileName);
            }

            date_default_timezone_set('Asia/Kolkata');

            $newUser = DB::table('contactus') 
                                ->insert([
                                    'user_name' => $request-> name,
                                    'user_email' => $request-> email,
                                    'user_subject' => $request-> subject,
                                    'user_file' => $fileName,
                                    'user_message' => $request-> desc,
                                    'created_at' => now(),
                                    'updated_at' => now()
                                ]); 

            if([$newUser]){
                return redirect()->back()->with('msg', 'Data Successfully Added');
                // echo "<h4>Data Successfully Added</h4>"; 
            } else {
                return redirect()->back()->with('msg', 'Faileds while sending code!');
                // echo "<h4>Faileds while sending code!</h4>";
            }


        }

}
