-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Oct 31, 2023 at 02:07 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `newsapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `contactus`
--

CREATE TABLE `contactus` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_file` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_message` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contactus`
--

INSERT INTO `contactus` (`id`, `user_name`, `user_email`, `user_subject`, `user_file`, `user_message`, `created_at`, `updated_at`) VALUES
(2, 'Shahrukhan', 'shahrukhkhan@gmail.com', 'best test subject', NULL, 'adasdfa', '2023-09-05 23:42:48', '2023-10-04 02:49:07'),
(3, 'Salman Khan', 'salman@gmail.com', 'runnin test subject', NULL, 'this dummy message', '2023-09-05 23:42:48', '2023-09-05 23:42:48'),
(4, 'sanjya', 'sanjay@gmail.com', 'ak to test subject', NULL, 'test bessage', '2023-09-05 23:42:48', '2023-10-04 02:49:47'),
(5, 'Yahoo Baba', 'yahoobaba@gmail.com', 'yahoo test subject', NULL, 'Yahoo Baba message', '2023-09-05 23:42:48', '2023-09-05 23:42:48'),
(6, 'Shahrukh Khan', 'shahrukha@gmail.com', 'best test subject', NULL, 'this best option for database message', '2023-09-05 23:42:48', '2023-09-05 23:42:48'),
(7, 'Salman Khan', 'salman@gmail.com', 'runnin test subject', NULL, 'this dummy message', '2023-09-05 23:42:48', '2023-09-05 23:42:48'),
(121, 'Vijay', 'vijay2545@gmail.com', 'test for image', '1698746168_card_spritesheet_1.png', 'test file', '2023-10-31 09:56:08', '2023-10-31 09:56:08'),
(122, 'sunil sharma', 'user@gmail.com', 'test for subject', '1698752691_1680774007_1613939980.png', 'asfdasdfasd', '2023-10-31 11:44:51', '2023-10-31 11:44:51'),
(123, 'admin@admin.com', 'admin@admin.com', 'asdfasd', '1698752770_1680774007_1613939980.png', 'asdasfasfasd', '2023-10-31 11:46:10', '2023-10-31 11:46:10'),
(124, 'dilipkumar', 'dilipkumar@gmail.com', 'text subject', '1698752845_1680843058_55484026.jpeg', 'test file', '2023-10-31 11:47:25', '2023-10-31 11:47:25'),
(125, 'subhash', 'subhash@gmail.com', 'test file', '1698752952_Forxiga Coin AW - Deliver - FRONT-01.png', 'test', '2023-10-31 11:49:12', '2023-10-31 11:49:12');

-- --------------------------------------------------------

--
-- Table structure for table `enquiry_form`
--

CREATE TABLE `enquiry_form` (
  `user_id` int(11) NOT NULL,
  `user_gender` varchar(11) DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `user_mobile` varchar(50) DEFAULT NULL,
  `user_email` varchar(255) DEFAULT NULL,
  `user_country` varchar(50) DEFAULT NULL,
  `user_state` varchar(50) DEFAULT NULL,
  `user_city` varchar(50) DEFAULT NULL,
  `user_service` varchar(255) DEFAULT NULL,
  `user_file` varchar(255) DEFAULT NULL,
  `user_message` varchar(255) DEFAULT NULL,
  `user_created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `enquiry_form`
--

INSERT INTO `enquiry_form` (`user_id`, `user_gender`, `user_name`, `user_mobile`, `user_email`, `user_country`, `user_state`, `user_city`, `user_service`, `user_file`, `user_message`, `user_created_at`) VALUES
(1, 'Mr', 'shashank Sharma', '9854845661', 'shashanksharma@gmail.com', 'in', 'raj', 'in', NULL, '1698757343_1680843058_55484026.jpeg', 'test message', '2023-10-31 13:02:23'),
(2, 'Miss', 'meena Kumari', '9254845455', 'meenakumari@gmail.com', 'in', 'raj', 'in', NULL, '1698757461_1680773795_2091310488.jpeg', 'test message for uploaded', '2023-10-31 13:04:21'),
(3, 'Mr', 'khurana', '7987646546', 'khurana@gmail.com', 'in', 'raj', 'us', 'react', '1698757573_Modi Ji.png', 'test message for business', '2023-10-31 13:06:13');

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE `files` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(2, '2023_09_05_052758_create_contactus_table', 1),
(3, '2023_09_11_044026_create_files_table', 2),
(4, '2023_09_13_092823_create_admins_table', 3);

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `admins_email_unique` (`email`);

--
-- Indexes for table `contactus`
--
ALTER TABLE `contactus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `enquiry_form`
--
ALTER TABLE `enquiry_form`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `contactus`
--
ALTER TABLE `contactus`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=126;

--
-- AUTO_INCREMENT for table `enquiry_form`
--
ALTER TABLE `enquiry_form`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `files`
--
ALTER TABLE `files`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
